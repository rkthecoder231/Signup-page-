document.getElementById("signupForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const form = e.target;
  const firstName = form.firstName.value.trim();
  const lastName = form.lastName.value.trim();
  const phone = form.phone.value.trim();
  const email = form.email.value.trim();
  const password = form.password.value;
  const confirmPassword = form.confirmPassword.value;

  if (!firstName || !lastName || !phone || !email || !password || !confirmPassword) {
    alert("All fields are required.");
    return;
  }

  if (!/^\d{10,15}$/.test(phone)) {
    alert("Enter a valid phone number.");
    return;
  }

  if (!/\S+@\S+\.\S+/.test(email)) {
    alert("Enter a valid email address.");
    return;
  }

  if (password.length < 6) {
    alert("Password must be at least 6 characters.");
    return;
  }

  if (password !== confirmPassword) {
    alert("Passwords do not match.");
    return;
  }

  alert("Form submitted successfully!");
});
